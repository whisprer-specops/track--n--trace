# Transport Client — Migration Guide

## What's new

Your existing `transport.rs` becomes `transport/mod.rs` with four new submodules:

| File | Lines | Purpose |
|------|-------|---------|
| `mod.rs` | 349 | Existing types + module declarations + shared helpers |
| `rate_limit.rs` | 327 | Per-domain sliding-window rate limiter |
| `circuit_breaker.rs` | 337 | Per-domain circuit breaker (closed/open/half-open) |
| `retry.rs` | 310 | Backoff strategies + retry policy engine |
| `client.rs` | 610 | `TransportClient` composing all of the above |

**Total: 1,933 lines. Zero new dependencies.**

## Installation steps

1. **Delete** `src/transport.rs`
2. **Create** `src/transport/` directory
3. **Copy** all five `.rs` files into `src/transport/`
4. **No changes needed** to `lib.rs` — `mod transport;` works for both files and directories

Your existing imports (`use crate::transport::{HttpRequestProfile, TransportError, ...}`) remain valid.

## What changed in mod.rs vs your original transport.rs

- `TransportError` gained three new variants: `RateLimited`, `CircuitOpen`, `RetriesExhausted`
- `ProxyRoute` gained a `label()` method (returns `"direct"`, `"tor_default"`, etc.)
- `apply_auth` factored out as a `pub(crate)` helper (was inline in `http_get_text`)
- `extract_domain` utility added as `pub(crate)`
- User agent bumped from `"skeletrace/0.5"` to `"skeletrace/0.9"` to match Cargo.toml
- `http_get_text` is preserved unchanged for backward compatibility

**If you have code that exhaustively matches on `TransportError`, you'll need to add arms for the three new variants.**

## Basic usage

```rust
use std::time::Duration;
use crate::transport::client::{TransportClient, SourceClass};
use crate::transport::HttpRequestProfile;

// Create client with sensible defaults
let mut client = TransportClient::new();

// Register domains with source-class presets
client.register_domain("api.opensky-network.org", SourceClass::SafeDefault);
client.register_domain("gdacs.org", SourceClass::Feed);
client.register_domain("companies-house.gov.uk", SourceClass::SafeDefault);
client.register_domain("secret.onion", SourceClass::Gated);

// Make requests — rate limiting, circuit breaking, retry all automatic
let profile = HttpRequestProfile::direct(Duration::from_secs(15));
match client.get_text("https://api.opensky-network.org/api/states/all", &profile) {
    Ok(resp) => {
        println!("Status: {}", resp.meta.status);
        println!("Duration: {:?}", resp.meta.total_duration);
        println!("Retries: {}", resp.meta.retry_count);
        println!("Body length: {}", resp.body.len());
    }
    Err(e) => eprintln!("Error: {e}"),
}
```

## Source class presets

| Class | Rate | Circuit | Retry | Use for |
|-------|------|---------|-------|---------|
| `SafeDefault` | 60/min, no interval | 10 fails, 60s cooldown | 3x exponential 1s→30s | Public APIs, registries, sanctions |
| `Feed` | 20/min, 3s interval | 5 fails, 120s cooldown | 2x exponential 2s→60s | RSS/Atom polling |
| `Controlled` | 10/min, 2s interval | 5 fails, 120s cooldown | 2x exponential 2s→60s | Rate-limited APIs, scraping |
| `Gated` | 2/min, 15s interval | 3 fails, 300s cooldown | 1x fixed 30s | Onion services, high-risk |
| `Custom{...}` | You decide | You decide | You decide | Everything else |

## Non-blocking mode

For an engine that doesn't want to sleep on rate limits:

```rust
let mut client = TransportClient::new()
    .with_block_on_rate_limit(false);

// Returns Err(TransportError::RateLimited { wait_ms, .. }) immediately
// instead of sleeping — your scheduler can decide what to do.
```

## Observability

```rust
client.circuit_state("api.example.com")   // CircuitState::Closed/Open/HalfOpen
client.rate_limit_count("api.example.com") // requests in current window
client.total_failures("api.example.com")   // lifetime failure count
client.total_successes("api.example.com")  // lifetime success count
```

## Tests

All four submodules include unit tests. Run with:

```sh
cargo test --lib transport
```
