#[cfg(feature = "tui")]
use std::error::Error;
#[cfg(feature = "tui")]
use std::io::{stdout, Write};
#[cfg(feature = "tui")]
use std::time::{Duration, Instant};

#[cfg(feature = "tui")]
use clap::Parser;
#[cfg(feature = "tui")]
use crossterm::cursor::{Hide, Show};
#[cfg(feature = "tui")]
use crossterm::event::{poll, read, Event as CEvent, KeyCode};
#[cfg(feature = "tui")]
use crossterm::execute;
#[cfg(feature = "tui")]
use crossterm::terminal::{self, EnterAlternateScreen, LeaveAlternateScreen};

#[cfg(feature = "tui")]
use maxwells_demon_detector::cli::{Cli, Mode};
#[cfg(feature = "tui")]
use maxwells_demon_detector::model::AppState;
#[cfg(feature = "tui")]
use maxwells_demon_detector::{render, source};

#[cfg(feature = "tui")]
struct TerminalGuard;

#[cfg(feature = "tui")]
impl TerminalGuard {
    fn enter() -> Result<Self, Box<dyn Error>> {
        terminal::enable_raw_mode()?;
        execute!(stdout(), EnterAlternateScreen, Hide)?;
        Ok(Self)
    }
}

#[cfg(feature = "tui")]
impl Drop for TerminalGuard {
    fn drop(&mut self) {
        let _ = execute!(stdout(), Show, LeaveAlternateScreen);
        let _ = terminal::disable_raw_mode();
    }
}

#[cfg(feature = "tui")]
fn maybe_quit() -> Result<bool, Box<dyn Error>> {
    while poll(Duration::from_millis(0))? {
        if let CEvent::Key(key) = read()? {
            if matches!(key.code, KeyCode::Char('q') | KeyCode::Esc) {
                return Ok(true);
            }
        }
    }
    Ok(false)
}

#[cfg(feature = "tui")]
fn main() -> Result<(), Box<dyn Error>> {
    let cli = Cli::parse();

    if cli.mode == Mode::ListInterfaces {
        source::print_interfaces()?;
        return Ok(());
    }

    let mut source = source::build_source(&cli)?;
    let _guard = TerminalGuard::enter()?;

    let (term_w, _) = terminal::size()?;
    let width = cli
        .width
        .unwrap_or_else(|| term_w.saturating_sub(24).max(32) as usize);

    let mut state = AppState::new(width, cli.tick_ms, cli.max_alerts);
    let tick = Duration::from_millis(cli.tick_ms.max(1));

    let mut last_tick = Instant::now();
    let mut stdout = stdout();

    loop {
        if maybe_quit()? {
            break;
        }

        let now = Instant::now();
        let elapsed = now.saturating_duration_since(last_tick);
        let budget = elapsed.min(tick.saturating_mul(4));
        let events = source.poll(budget)?;
        for ev in events {
            state.ingest(ev);
        }

        if elapsed >= tick {
            state.finalize_tick();
            render::draw(&mut stdout, &state, cli.mode.label())?;
            stdout.flush()?;
            last_tick = now;
        } else {
            std::thread::sleep(tick - elapsed);
        }
    }

    Ok(())
}

#[cfg(not(feature = "tui"))]
fn main() {
    eprintln!("The terminal application target requires the `tui` feature. Build with default features or enable `tui`.");
    std::process::exit(1);
}
