pub mod cli;
pub mod event;
pub mod model;
pub mod render;
pub mod source;
pub mod stats;
pub mod verify;

pub use event::{Lane, PacketEvent};
pub use model::{AppState, Cell};
pub use verify::{verify_events, LaneSummary, VerificationReport};
