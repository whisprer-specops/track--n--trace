//! # Skeletrace: Sparse Spatiotemporal Flow-Graph Engine
//!
//! Skeletrace is a topology-aware probe engine for OSINT telemetry and
//! communications signal flow monitoring. It provides the foundational
//! data structures and algorithms for building resilient monitoring systems
//! that can adapt to changing network conditions and identify critical
//! infrastructure dependencies.
//!
//! ## Architecture
//!
//! - **`types`** — Identity newtypes, timestamps, bounded scalars.
//! - **`spatial`** — Minimal world scaffold: coordinates, ellipsoid math.
//! - **`entity`** — The sparse graph core: nodes, edges, flows.
//! - **`metric`** — Metric dictionary and append-only sample records.
//! - **`cache`** — Tiered hot/warm/cold memory model with TTL eviction.
//! - **`view`** — View/render contract: what gets fetched and when.
//! - **`graph`** — The sparse graph store: add/get/remove nodes, edges, flows.
//! - **`ingest`** — Scheduler/collector/normalizer pipeline definitions.
//! - **`snapshot`** — Selective investigation artifacts for export.
//! - **`probe`** — Topology-aware probe engine for communications signal flow monitoring.
//!
//! ## Example Usage
//!
//! ```rust
//! use skeletrace::{Graph, probe::{ProbeEngine, ProbeTarget}};
//! use skeletrace::entity::{Node, NodeKind};
//! use skeletrace::types::EntityId;
//!
//! // Create a graph and add some nodes
//! let mut graph = Graph::new();
//! 
//! // Set up probe engine
//! let mut probe_engine = ProbeEngine::new();
//! 
//! // Add a probe target
//! let entity_id = EntityId(uuid::Uuid::new_v4());
//! let target = ProbeTarget::http_get(
//!     entity_id,
//!     "https://api.example.com/health",
//!     "API Health Check"
//! );
//! probe_engine.add_target(target);
//! ```

pub mod types;
pub mod spatial;
pub mod entity;
pub mod metric;
pub mod cache;
pub mod view;
pub mod graph;
pub mod ingest;
pub mod snapshot;
pub mod probe;

// Re-export commonly used types
pub use graph::Graph;
pub use types::{EntityId, MetricId, SourceId, Timestamp};
